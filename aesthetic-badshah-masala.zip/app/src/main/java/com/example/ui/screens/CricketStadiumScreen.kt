package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.CurrentMatch
import com.example.model.DeliveryLength
import com.example.model.ShotResult
import com.example.model.ShotType
import com.example.model.StadiumLightingPreset
import com.example.ui.components.AudioSettingsDialog
import com.example.ui.components.TerminalTelemetryOverlay
import com.example.viewmodel.CricketGameViewModel
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CricketStadiumScreen(
    viewModel: CricketGameViewModel,
    onBackToMenu: () -> Unit
) {
    val match by viewModel.match.collectAsState()
    val ballProgress by viewModel.ballProgress.collectAsState()
    val isBallInAir by viewModel.isBallInAir.collectAsState()
    val currentDelivery by viewModel.currentDelivery.collectAsState()
    val swingDrift by viewModel.swingDrift.collectAsState()
    val batSwingAngle by viewModel.batSwingAngle.collectAsState()
    val selectedShot by viewModel.selectedShot.collectAsState()
    val isSixCelebration by viewModel.isSixCelebration.collectAsState()
    val sixBallFlightProgress by viewModel.sixBallFlightProgress.collectAsState()
    val isWicketDown by viewModel.isWicketDown.collectAsState()
    val particles by viewModel.particles.collectAsState()
    val audioSettings by viewModel.audioController.settings.collectAsState()
    val stadiumLighting by viewModel.stadiumLighting.collectAsState()

    var showAudioDialog by remember { mutableStateOf(false) }

    if (showAudioDialog) {
        AudioSettingsDialog(
            audioController = viewModel.audioController,
            onDismiss = { showAudioDialog = false }
        )
    }

    // Celebration flash & glow pulse
    val infiniteTransition = rememberInfiniteTransition(label = "stadiumLight")
    val stadiumLightPulse by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "stadiumGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                when (stadiumLighting) {
                    StadiumLightingPreset.DAY -> Color(0xFF1E3A8A)
                    StadiumLightingPreset.DUSK -> Color(0xFF2E1020)
                    StadiumLightingPreset.NIGHT -> Color(0xFF070B14)
                }
            )
    ) {
        // 1. Realistic Stadium Background with atmospheric lighting overlay
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = R.drawable.img_cricket_stadium),
                contentDescription = "Cricket Stadium",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(if (isSixCelebration) 0.85f else 0.65f)
            )

            // Dynamic atmosphere gradient based on Day / Dusk / Night
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        when (stadiumLighting) {
                            StadiumLightingPreset.DAY -> Brush.verticalGradient(
                                listOf(
                                    Color(0x4038BDF8),
                                    Color(0x2260A5FA),
                                    Color(0x10BAE6FD),
                                    Color.Transparent
                                )
                            )
                            StadiumLightingPreset.DUSK -> Brush.verticalGradient(
                                listOf(
                                    Color(0x774A044E),
                                    Color(0x669A3412),
                                    Color(0x44EA580C),
                                    Color(0x22FBBF24),
                                    Color.Transparent
                                )
                            )
                            StadiumLightingPreset.NIGHT -> Brush.verticalGradient(
                                listOf(
                                    Color(0x99030712),
                                    Color(0x660B132B),
                                    Color.Transparent
                                )
                            )
                        }
                    )
            )
        }

        // 2. 3D Stadium Field & Cricket Pitch Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Dynamic floodlight beams & celestial lighting (Sun / Dusk Sun / Night Floodlights)
            drawFloodlightBeams(width, height, isSixCelebration, stadiumLightPulse, stadiumLighting)

            // Perspective Ground & Turf Pitch
            draw3DPitch(width, height, stadiumLighting)

            // Crease Lines
            drawCreaseLines(width, height)

            // Draw Bowler running in & delivery action at the far end
            drawBowler(width, height, ballProgress, isBallInAir)

            // Draw Wickets & Bails behind batsman
            drawWickets(width, height, isWicketDown)

            // Draw Cricket Batsman
            drawBatsman(width, height, batSwingAngle, isSixCelebration, selectedShot)

            // Draw Bowled Cricket Ball (traveling towards batsman in 3D perspective)
            if (isBallInAir) {
                drawBowledBall(width, height, ballProgress, swingDrift, currentDelivery, stadiumLighting)
            }

            // Draw Six Ball flight arc if active
            if (isSixCelebration) {
                drawSixFlightBall(width, height, sixBallFlightProgress, selectedShot)
            }

            // Draw celebratory confetti / fireworks particles
            particles.forEach { p ->
                drawCircle(
                    color = Color(p.color).copy(alpha = p.alpha),
                    radius = p.radius,
                    center = Offset(p.x * width, p.y * height)
                )
            }
        }

        // 3. Top HUD: Scoreboard, Overs, Sixes Counter, Navigation, Lighting Preset
        TopScoreboardHUD(
            match = match,
            currentDelivery = currentDelivery,
            isBallInAir = isBallInAir,
            isMuted = audioSettings.isMuted,
            stadiumLighting = stadiumLighting,
            onToggleRandomLighting = { viewModel.toggleRandomLighting() },
            onToggleMute = { viewModel.audioController.toggleMute() },
            onOpenAudioSettings = { showAudioDialog = true },
            onBackToMenu = onBackToMenu
        )

        // 3.5 Terminal-Style Floating Telemetry Overlay (Real-time logs & packet data while batting)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 136.dp)
        ) {
            TerminalTelemetryOverlay(
                isBallInAir = isBallInAir,
                ballProgress = ballProgress,
                currentDelivery = currentDelivery,
                swingDrift = swingDrift,
                selectedShot = selectedShot,
                lastShotResult = match.lastShotResult,
                lastShotDistance = match.lastShotDistance,
                isSixCelebration = isSixCelebration,
                stadiumLighting = stadiumLighting
            )
        }

        // 4. Six Celebration Overlay Event Banner
        AnimatedVisibility(
            visible = isSixCelebration,
            enter = fadeIn(tween(150)) + scaleIn(tween(250)),
            exit = fadeOut(tween(400)) + scaleOut(tween(300)),
            modifier = Modifier.align(Alignment.Center)
        ) {
            SixCelebrationBanner(
                distanceMeters = match.lastShotDistance,
                stadiumLightPulse = stadiumLightPulse
            )
        }

        // 5. Shot Feedback Toast when regular shot hit
        if (!isSixCelebration && match.lastShotResult != null && !isBallInAir) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-70).dp)
            ) {
                ShotFeedbackChip(result = match.lastShotResult!!)
            }
        }

        // 6. Bottom Controls: Shot Selector, Batting Hit Button & Sweet Spot Timing Meter
        BottomBattingControls(
            isBallInAir = isBallInAir,
            ballProgress = ballProgress,
            selectedShot = selectedShot,
            onSelectShot = { viewModel.selectShot(it) },
            onBatSwing = { viewModel.onBatSwing() },
            isSixCelebration = isSixCelebration,
            isGameOver = match.isGameOver,
            onNextBall = { viewModel.bowlNextBall() }
        )

        // 7. Match Over Dialog
        if (match.isGameOver) {
            MatchOverDialog(
                match = match,
                onPlayAgain = { viewModel.startNewMatch() },
                onMainMenu = onBackToMenu
            )
        }
    }
}

// ----------------------------------------------------------------------------
// Custom 3D Stadium Drawing Functions
// ----------------------------------------------------------------------------

private fun DrawScope.drawFloodlightBeams(
    w: Float,
    h: Float,
    isSix: Boolean,
    pulse: Float,
    lighting: StadiumLightingPreset
) {
    when (lighting) {
        StadiumLightingPreset.DAY -> {
            // Bright afternoon sun in upper sky
            val sunCenter = Offset(w * 0.82f, h * 0.12f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x77FFF9C4), Color(0x33FFE082), Color.Transparent),
                    center = sunCenter,
                    radius = w * 0.45f
                ),
                radius = w * 0.45f,
                center = sunCenter
            )
            drawCircle(
                color = Color(0xFFFFFDE7),
                radius = 22f,
                center = sunCenter
            )
        }
        StadiumLightingPreset.DUSK -> {
            // Sunset sun settling behind the stands with warm golden-hour dusk beams
            val sunsetCenter = Offset(w * 0.78f, h * 0.26f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x88F97316), Color(0x55EA580C), Color(0x22B91C1C), Color.Transparent),
                    center = sunsetCenter,
                    radius = w * 0.55f
                ),
                radius = w * 0.55f,
                center = sunsetCenter
            )
            // Warm amber floodlight glow warming up
            val duskBeamColor = if (isSix) Color(0x44FFB800) else Color(0x28F59E0B)
            val leftBeam = Path().apply {
                moveTo(0f, 40f)
                lineTo(w * 0.45f, h * 0.7f)
                lineTo(w * 0.1f, h * 0.95f)
                close()
            }
            drawPath(leftBeam, duskBeamColor)

            val rightBeam = Path().apply {
                moveTo(w, 40f)
                lineTo(w * 0.55f, h * 0.7f)
                lineTo(w * 0.9f, h * 0.95f)
                close()
            }
            drawPath(rightBeam, duskBeamColor)
        }
        StadiumLightingPreset.NIGHT -> {
            val beamColor = if (isSix) {
                Color(0x33FFB800) // Golden celebration glow
            } else {
                Color(0x2400E5FF) // Electric night cyan floodlights
            }

            val leftBeam = Path().apply {
                moveTo(0f, 40f)
                lineTo(w * 0.45f, h * 0.7f)
                lineTo(w * 0.1f, h * 0.95f)
                close()
            }
            drawPath(leftBeam, beamColor)

            val rightBeam = Path().apply {
                moveTo(w, 40f)
                lineTo(w * 0.55f, h * 0.7f)
                lineTo(w * 0.9f, h * 0.95f)
                close()
            }
            drawPath(rightBeam, beamColor)
        }
    }

    // Six celebration flash effect
    if (isSix) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x44FFB800), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.4f),
                radius = w * 0.8f * pulse
            ),
            radius = w * 0.8f * pulse,
            center = Offset(w * 0.5f, h * 0.4f)
        )
    }
}

private fun DrawScope.draw3DPitch(w: Float, h: Float, lighting: StadiumLightingPreset) {
    // 3D Perspective Turf Pitch
    // Top (bowling end) is narrow, Bottom (batting end) is wide
    val topY = h * 0.44f
    val bottomY = h * 0.78f

    val topWidth = w * 0.18f
    val bottomWidth = w * 0.65f

    val centerX = w * 0.5f

    val pitchPath = Path().apply {
        moveTo(centerX - topWidth / 2f, topY)
        lineTo(centerX + topWidth / 2f, topY)
        lineTo(centerX + bottomWidth / 2f, bottomY)
        lineTo(centerX - bottomWidth / 2f, bottomY)
        close()
    }

    // Pitch color tailored to Day, Dusk, or Night
    val pitchColors = when (lighting) {
        StadiumLightingPreset.DAY -> listOf(
            Color(0xFFA17F55), // Sunlit clay
            Color(0xFFC7A276), // Mid pitch
            Color(0xFFDCB88B)  // Batting crease clay
        )
        StadiumLightingPreset.DUSK -> listOf(
            Color(0xFF8C5137), // Sunset amber clay
            Color(0xFFB57049),
            Color(0xFFCE875E)
        )
        StadiumLightingPreset.NIGHT -> listOf(
            Color(0xFF8B775A), // Distant clay
            Color(0xFFB59D77), // Mid pitch
            Color(0xFFC7AF87)  // Batting crease clay
        )
    }

    drawPath(
        path = pitchPath,
        brush = Brush.verticalGradient(
            colors = pitchColors,
            startY = topY,
            endY = bottomY
        )
    )

    // Pitch border / edge lines
    val borderColor = when (lighting) {
        StadiumLightingPreset.DAY -> Color(0x88FFFFFF)
        StadiumLightingPreset.DUSK -> Color(0x66FFD180)
        StadiumLightingPreset.NIGHT -> Color(0x66FFFFFF)
    }
    drawPath(
        path = pitchPath,
        color = borderColor,
        style = Stroke(width = 1.5f)
    )

    // Good length bounce marking zone
    val bounceY = topY + (bottomY - topY) * 0.64f
    val bounceW = topWidth + (bottomWidth - topWidth) * 0.64f
    drawLine(
        color = borderColor.copy(alpha = 0.4f),
        start = Offset(centerX - bounceW * 0.45f, bounceY),
        end = Offset(centerX + bounceW * 0.45f, bounceY),
        strokeWidth = 2f
    )
}

private fun DrawScope.drawCreaseLines(w: Float, h: Float) {
    val centerX = w * 0.5f
    val bottomY = h * 0.78f
    val battingCreaseY = bottomY - 35f

    // Popping crease (white chalk line)
    drawLine(
        color = Color.White.copy(alpha = 0.9f),
        start = Offset(centerX - w * 0.32f, battingCreaseY),
        end = Offset(centerX + w * 0.32f, battingCreaseY),
        strokeWidth = 4f
    )

    // Return creases
    drawLine(
        color = Color.White.copy(alpha = 0.8f),
        start = Offset(centerX - w * 0.28f, battingCreaseY),
        end = Offset(centerX - w * 0.28f, bottomY),
        strokeWidth = 3f
    )
    drawLine(
        color = Color.White.copy(alpha = 0.8f),
        start = Offset(centerX + w * 0.28f, battingCreaseY),
        end = Offset(centerX + w * 0.28f, bottomY),
        strokeWidth = 3f
    )
}

private fun DrawScope.drawBowler(w: Float, h: Float, progress: Float, isAir: Boolean) {
    val bowlerX = w * 0.5f + (sin(progress * 8f) * 6f)
    val bowlerY = h * 0.42f

    // Bowler jersey (Vibrant Cyan / Badshah Gold)
    // Head
    drawCircle(
        color = Color(0xFFD29B72),
        radius = 7f,
        center = Offset(bowlerX, bowlerY - 14f)
    )
    // Torso / Jersey
    drawRoundRect(
        color = Color(0xFF00B0FF),
        topLeft = Offset(bowlerX - 8f, bowlerY - 6f),
        size = Size(16f, 18f),
        cornerRadius = CornerRadius(4f, 4f)
    )
    // Trousers
    drawLine(
        color = Color.White,
        start = Offset(bowlerX - 4f, bowlerY + 12f),
        end = Offset(bowlerX - 6f, bowlerY + 28f),
        strokeWidth = 4f
    )
    drawLine(
        color = Color.White,
        start = Offset(bowlerX + 4f, bowlerY + 12f),
        end = Offset(bowlerX + 6f, bowlerY + 28f),
        strokeWidth = 4f
    )
    // Bowling arm wind-up
    val armAngle = if (isAir && progress < 0.2f) (progress * 180f) else 45f
    val armEndX = bowlerX + cos(Math.toRadians(armAngle.toDouble())).toFloat() * 14f
    val armEndY = bowlerY - 8f - sin(Math.toRadians(armAngle.toDouble())).toFloat() * 14f
    drawLine(
        color = Color(0xFF00B0FF),
        start = Offset(bowlerX + 6f, bowlerY - 2f),
        end = Offset(armEndX, armEndY),
        strokeWidth = 4f
    )
}

private fun DrawScope.drawWickets(w: Float, h: Float, isWicketDown: Boolean) {
    val wicketX = w * 0.5f - 8f
    val wicketBaseY = h * 0.77f
    val stumpHeight = 44f
    val stumpWidth = 4f
    val woodColor = Color(0xFFE5A65E)

    if (!isWicketDown) {
        // 3 Stumps
        for (i in 0..2) {
            val sx = wicketX + i * 8f
            drawRoundRect(
                color = woodColor,
                topLeft = Offset(sx, wicketBaseY - stumpHeight),
                size = Size(stumpWidth, stumpHeight),
                cornerRadius = CornerRadius(2f, 2f)
            )
        }
        // 2 Bails across stumps
        drawRoundRect(
            color = Color(0xFFFFD54F),
            topLeft = Offset(wicketX - 2f, wicketBaseY - stumpHeight - 3f),
            size = Size(20f, 4f),
            cornerRadius = CornerRadius(1.5f, 1.5f)
        )
    } else {
        // Clean bowled! Flying bails and tilted stumps
        // Off stump tilted
        rotate(degrees = -35f, pivot = Offset(wicketX, wicketBaseY)) {
            drawRoundRect(
                color = woodColor,
                topLeft = Offset(wicketX - 10f, wicketBaseY - stumpHeight),
                size = Size(stumpWidth, stumpHeight)
            )
        }
        // Middle stump tilted
        rotate(degrees = 25f, pivot = Offset(wicketX + 8f, wicketBaseY)) {
            drawRoundRect(
                color = woodColor,
                topLeft = Offset(wicketX + 8f, wicketBaseY - stumpHeight),
                size = Size(stumpWidth, stumpHeight)
            )
        }
        // Flying bails in air
        drawRoundRect(
            color = Color(0xFFFFD54F),
            topLeft = Offset(wicketX - 18f, wicketBaseY - stumpHeight - 25f),
            size = Size(14f, 4f)
        )
        drawRoundRect(
            color = Color(0xFFFFD54F),
            topLeft = Offset(wicketX + 16f, wicketBaseY - stumpHeight - 32f),
            size = Size(14f, 4f)
        )
    }
}

private fun DrawScope.drawBatsman(
    w: Float,
    h: Float,
    swingAngle: Float,
    isSixCelebration: Boolean,
    shotType: ShotType
) {
    val batsmanX = w * 0.5f + 42f
    val batsmanY = h * 0.72f

    // Batsman celebratory stance or batting stance
    if (isSixCelebration) {
        // Raising bat high with both arms!
        // Helmet (Badshah Gold & Navy)
        drawCircle(
            color = Color(0xFF0F2B5C),
            radius = 12f,
            center = Offset(batsmanX, batsmanY - 45f)
        )
        // Face grill
        drawLine(
            color = Color(0xFFFFB800),
            start = Offset(batsmanX - 6f, batsmanY - 43f),
            end = Offset(batsmanX - 2f, batsmanY - 40f),
            strokeWidth = 2.5f
        )
        // Jersey
        drawRoundRect(
            color = Color(0xFFFFB800), // Badshah Gold jersey
            topLeft = Offset(batsmanX - 16f, batsmanY - 32f),
            size = Size(32f, 38f),
            cornerRadius = CornerRadius(6f, 6f)
        )
        // White pads
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(batsmanX - 14f, batsmanY + 6f),
            size = Size(12f, 32f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(batsmanX + 2f, batsmanY + 6f),
            size = Size(12f, 32f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        // Raised Bat held up in victory!
        rotate(degrees = -15f, pivot = Offset(batsmanX - 10f, batsmanY - 50f)) {
            // Bat handle
            drawRoundRect(
                color = Color(0xFFFFFFFF),
                topLeft = Offset(batsmanX - 6f, batsmanY - 80f),
                size = Size(5f, 22f)
            )
            // English Willow Bat blade
            drawRoundRect(
                color = Color(0xFFDEB887),
                topLeft = Offset(batsmanX - 9f, batsmanY - 128f),
                size = Size(11f, 50f),
                cornerRadius = CornerRadius(3f, 3f)
            )
            // Badshah sticker on bat
            drawRoundRect(
                color = Color(0xFFFF334B),
                topLeft = Offset(batsmanX - 8f, batsmanY - 115f),
                size = Size(9f, 22f)
            )
        }
    } else {
        // Standard Ready / Swinging Stance
        // Helmet
        drawCircle(
            color = Color(0xFF0F2B5C),
            radius = 11f,
            center = Offset(batsmanX - 8f, batsmanY - 42f)
        )
        // Jersey
        drawRoundRect(
            color = Color(0xFFFFB800),
            topLeft = Offset(batsmanX - 22f, batsmanY - 30f),
            size = Size(28f, 34f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        // Cricket Pads
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(batsmanX - 20f, batsmanY + 4f),
            size = Size(11f, 32f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(batsmanX - 6f, batsmanY + 4f),
            size = Size(11f, 32f),
            cornerRadius = CornerRadius(3f, 3f)
        )

        // Willow Bat with dynamic rotation during swing
        val baseAngle = -25f + swingAngle
        rotate(degrees = baseAngle, pivot = Offset(batsmanX - 12f, batsmanY - 8f)) {
            // Handle
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(batsmanX - 14f, batsmanY - 26f),
                size = Size(5f, 20f)
            )
            // Blade
            drawRoundRect(
                color = Color(0xFFDEB887),
                topLeft = Offset(batsmanX - 17f, batsmanY - 68f),
                size = Size(11f, 44f),
                cornerRadius = CornerRadius(3f, 3f)
            )
            // Badshah Logo sticker on bat
            drawRoundRect(
                color = Color(0xFFFF334B),
                topLeft = Offset(batsmanX - 16f, batsmanY - 56f),
                size = Size(9f, 18f)
            )
        }
    }
}

private fun DrawScope.drawBowledBall(
    w: Float,
    h: Float,
    progress: Float,
    drift: Float,
    delivery: DeliveryLength,
    lighting: StadiumLightingPreset
) {
    val topY = h * 0.44f
    val bottomY = h * 0.74f

    // 3D perspective Y position
    val ballY = topY + (bottomY - topY) * progress

    // Horizontal drift / swing
    val centerX = w * 0.5f
    val ballX = centerX + (drift * w * progress * progress)

    // Ball 3D scale: small when released, large when reaching batsman
    val ballRadius = 4f + 13f * progress

    // Shadow on the pitch below ball
    val shadowY = ballY + (12f * (1f - progress))
    val shadowRadius = ballRadius * 0.9f
    val shadowColor = when (lighting) {
        StadiumLightingPreset.DAY -> Color(0x66000000) // Crisp dark shadow in daylight
        StadiumLightingPreset.DUSK -> Color(0x4D2A1208) // Warm amber twilight shadow
        StadiumLightingPreset.NIGHT -> Color(0x38000000) // Soft floodlight shadow
    }
    drawOval(
        color = shadowColor,
        topLeft = Offset(ballX - shadowRadius, shadowY - 3f),
        size = Size(shadowRadius * 2f, 6f)
    )

    // Pitch bounce effect (circle dust mark) when progress is around 0.65
    if (progress in 0.62f..0.72f) {
        val bounceAlpha = (1f - (progress - 0.62f) / 0.1f).coerceIn(0f, 1f)
        drawCircle(
            color = Color(0x66FFFFFF).copy(alpha = bounceAlpha),
            radius = 16f * (1f + (progress - 0.62f) * 10f),
            center = Offset(ballX, ballY),
            style = Stroke(width = 2.5f)
        )
    }

    // Cherry Red Leather Cricket Ball
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF4D4D), Color(0xFFB71C1C), Color(0xFF6B0E0E)),
            center = Offset(ballX - ballRadius * 0.3f, ballY - ballRadius * 0.3f),
            radius = ballRadius
        ),
        radius = ballRadius,
        center = Offset(ballX, ballY)
    )

    // White ball seam
    rotate(degrees = progress * 360f, pivot = Offset(ballX, ballY)) {
        drawLine(
            color = Color.White.copy(alpha = 0.85f),
            start = Offset(ballX - ballRadius * 0.8f, ballY),
            end = Offset(ballX + ballRadius * 0.8f, ballY),
            strokeWidth = 2f
        )
    }
}

private fun DrawScope.drawSixFlightBall(
    w: Float,
    h: Float,
    flightProgress: Float,
    shotType: ShotType
) {
    val startX = w * 0.5f + 25f
    val startY = h * 0.70f

    // 3D trajectory: shoots high up towards top stadium stands
    val targetX = when (shotType) {
        ShotType.PULL_SHOT -> w * 0.15f
        ShotType.COVER_DRIVE -> w * 0.85f
        else -> w * 0.48f
    }
    val targetY = h * 0.12f

    // Parabola height
    val peakHeight = h * 0.35f
    val currentX = startX + (targetX - startX) * flightProgress
    val currentY = startY + (targetY - startY) * flightProgress - (sin(flightProgress * Math.PI.toFloat()) * peakHeight)

    // Glowing flame trail
    drawCircle(
        color = Color(0x66FFB800),
        radius = 24f * (1f - flightProgress * 0.5f),
        center = Offset(currentX, currentY)
    )
    drawCircle(
        color = Color(0xFFFF334B),
        radius = 12f * (1f - flightProgress * 0.4f),
        center = Offset(currentX, currentY)
    )
    drawCircle(
        color = Color.White,
        radius = 7f,
        center = Offset(currentX, currentY)
    )
}

// ----------------------------------------------------------------------------
// Composables: HUD, Banners, Controls
// ----------------------------------------------------------------------------

@Composable
private fun TopScoreboardHUD(
    match: CurrentMatch,
    currentDelivery: DeliveryLength,
    isBallInAir: Boolean,
    isMuted: Boolean,
    stadiumLighting: StadiumLightingPreset,
    onToggleRandomLighting: () -> Unit,
    onToggleMute: () -> Unit,
    onOpenAudioSettings: () -> Unit,
    onBackToMenu: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        // Navigation & Quick Settings Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToMenu,
                modifier = Modifier
                    .background(Color(0x990A0E17), RoundedCornerShape(10.dp))
                    .size(38.dp)
                    .testTag("back_to_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Game Brand Title Badge
            Surface(
                color = Color(0xCC0B111D),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFFFB800).copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ASTHETIC BADSHAH",
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = Color(0xFFFFB800)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Stadium Lighting Preset Toggle (Day / Dusk / Night)
                Surface(
                    color = when (stadiumLighting) {
                        StadiumLightingPreset.DAY -> Color(0xFF1E3A8A)
                        StadiumLightingPreset.DUSK -> Color(0xFF7C2D12)
                        StadiumLightingPreset.NIGHT -> Color(0xFF0F172A)
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        1.dp,
                        when (stadiumLighting) {
                            StadiumLightingPreset.DAY -> Color(0xFF38BDF8)
                            StadiumLightingPreset.DUSK -> Color(0xFFF97316)
                            StadiumLightingPreset.NIGHT -> Color(0xFF00FF66)
                        }
                    ),
                    modifier = Modifier
                        .clickable { onToggleRandomLighting() }
                        .testTag("toggle_lighting_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stadiumLighting.iconEmoji,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stadiumLighting.label.uppercase(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier
                        .background(Color(0x990A0E17), RoundedCornerShape(10.dp))
                        .size(38.dp)
                        .testTag("quick_mute_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Mute",
                        tint = if (isMuted) Color(0xFFFF4D4D) else Color(0xFF00FF66),
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onOpenAudioSettings,
                    modifier = Modifier
                        .background(Color(0x990A0E17), RoundedCornerShape(10.dp))
                        .size(38.dp)
                        .testTag("game_audio_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SportsCricket,
                        contentDescription = "Audio Config",
                        tint = Color(0xFFFFB800),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main Scoreboard Bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF24334C), RoundedCornerShape(14.dp)),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xE60D1424))
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Big Score Display
                    Column {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${match.runs}/${match.wickets}",
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val overs = match.ballsBowled / 6
                            val overBalls = match.ballsBowled % 6
                            Text(
                                text = "($overs.$overBalls / ${match.maxOvers}.0)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF90A4AE),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        Text(
                            text = "CURRENT BOWLER: ${currentDelivery.label} (${currentDelivery.speedKph} km/h)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF00E5FF),
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Sixes badge in match
                    Surface(
                        color = Color(0xFF2C1E0A),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFFFB800))
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${match.sixesInMatch}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFFFB800)
                            )
                            Text(
                                text = "SIXES 🚀",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD54F)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Recent balls timeline
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "THIS OVER:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        match.recentBalls.reversed().forEach { ball ->
                            val (bg, fg) = when (ball) {
                                "6" -> Color(0xFFFFB800) to Color.Black
                                "4" -> Color(0xFF00E5FF) to Color.Black
                                "W" -> Color(0xFFFF334B) to Color.White
                                else -> Color(0xFF1E2838) to Color.White
                            }
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(bg, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ball,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = fg
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SixCelebrationBanner(
    distanceMeters: Int,
    stadiumLightPulse: Float
) {
    Card(
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .border(
                3.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFFFFB800),
                        Color(0xFFFF334B),
                        Color(0xFFFFB800)
                    )
                ),
                RoundedCornerShape(22.dp)
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xF2070D18))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "★ S I X ! ★",
                fontSize = 44.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFFFB800),
                letterSpacing = 4.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "OUT OF THE STADIUM! ${distanceMeters} METERS!",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 0.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = Color(0xFFFF334B),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "🔥 ASTHETIC BADSHAH MAXIMUM 🔥",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun ShotFeedbackChip(result: ShotResult) {
    Surface(
        color = Color(result.badgeColor).copy(alpha = 0.95f),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 6.dp
    ) {
        Text(
            text = result.message,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = if (result == ShotResult.SIX || result == ShotResult.FOUR) Color.Black else Color.White,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun BottomBattingControls(
    isBallInAir: Boolean,
    ballProgress: Float,
    selectedShot: ShotType,
    onSelectShot: (ShotType) -> Unit,
    onBatSwing: () -> Unit,
    isSixCelebration: Boolean,
    isGameOver: Boolean,
    onNextBall: () -> Unit
) {
    val isInHittingZone = ballProgress in 0.78f..0.94f
    val isPerfectSweetSpot = ballProgress in 0.82f..0.89f

    // Animated trigger button scale
    val buttonScale by animateFloatAsState(
        targetValue = if (isPerfectSweetSpot) 1.08f else 1f,
        label = "btnScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Shot Type Selector Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ShotType.values().forEach { shot ->
                val isSelected = selectedShot == shot
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectShot(shot) },
                    label = {
                        Text(
                            text = shot.label.split(" ").first(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    modifier = Modifier.padding(horizontal = 2.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFFFB800),
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0x99101827),
                        labelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Visual Timing Sweet Spot Meter
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0xFF1E2638))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(7.dp))
        ) {
            // Target Green Sweet Spot Zone (0.82 to 0.89)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.16f)
                        .height(10.dp)
                        .align(Alignment.CenterEnd)
                        .offset(x = (-30).dp)
                        .background(Color(0xFF00FF66), RoundedCornerShape(4.dp))
                )
            }

            // Moving ball timing indicator
            if (isBallInAir) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(ballProgress.coerceIn(0.05f, 1f))
                        .height(14.dp)
                        .background(
                            when {
                                isPerfectSweetSpot -> Color(0xFFFFB800)
                                isInHittingZone -> Color(0xFF00FF66)
                                ballProgress > 0.94f -> Color(0xFFFF334B)
                                else -> Color(0xFF00E5FF)
                            },
                            RoundedCornerShape(7.dp)
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Batting Action Button (or Next Ball trigger)
        if (!isBallInAir && !isGameOver && !isSixCelebration) {
            Button(
                onClick = onNextBall,
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(54.dp)
                    .testTag("bowl_next_ball_button"),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E5FF),
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Next Ball",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BOWL NEXT BALL",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }
        } else {
            Button(
                onClick = onBatSwing,
                enabled = isBallInAir && !isGameOver,
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(62.dp)
                    .scale(buttonScale)
                    .testTag("bat_swing_button"),
                shape = RoundedCornerShape(31.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        isPerfectSweetSpot -> Color(0xFFFFB800)
                        isInHittingZone -> Color(0xFF00FF66)
                        else -> Color(0xFFFF334B)
                    },
                    contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF334155),
                    disabledContentColor = Color.Gray
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsCricket,
                        contentDescription = "Bat",
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = when {
                            isPerfectSweetSpot -> "★ HIT SIX NOW! ★"
                            isInHittingZone -> "SWING BAT!"
                            isBallInAir -> "WAIT FOR TIMING..."
                            else -> "READY"
                        },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun MatchOverDialog(
    match: CurrentMatch,
    onPlayAgain: () -> Unit,
    onMainMenu: () -> Unit
) {
    Dialog(onDismissRequest = onMainMenu) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F1524),
            border = BorderStroke(2.dp, Color(0xFFFFB800)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "MATCH COMPLETED!",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFFFB800),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "${match.runs} RUNS",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Text(
                    text = "Wickets lost: ${match.wickets} • Sixes hit: ${match.sixesInMatch}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.LightGray
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onPlayAgain,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFB800),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("play_again_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Replay"
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAY NEXT INNINGS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onMainMenu,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dialog_main_menu_button")
                ) {
                    Text(
                        text = "RETURN TO MAIN MENU",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}
