package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BadshahGold = Color(0xFFFFB800)
val BadshahGoldDark = Color(0xFFC78F00)
val BadshahOrange = Color(0xFFFF6B00)
val BadshahRed = Color(0xFFFF334B)
val HackerGreen = Color(0xFF00FF66)
val StadiumCyan = Color(0xFF00E5FF)

val DarkSurface = Color(0xFF0F1524)
val DarkBackground = Color(0xFF070B13)
val DarkCard = Color(0xFF131B2D)
val DarkBorder = Color(0xFF23304A)
