package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeliveryLength
import com.example.model.ShotResult
import com.example.model.ShotType
import com.example.model.StadiumLightingPreset
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class TelemetryLog(
    val id: Long = System.nanoTime(),
    val timestamp: String,
    val tag: String,
    val message: String,
    val tagColor: Color = Color(0xFF00FF66),
    val msgColor: Color = Color(0xFFB0FFC8)
)

@Composable
fun TerminalTelemetryOverlay(
    isBallInAir: Boolean,
    ballProgress: Float,
    currentDelivery: DeliveryLength,
    swingDrift: Float,
    selectedShot: ShotType,
    lastShotResult: ShotResult?,
    lastShotDistance: Int,
    isSixCelebration: Boolean,
    stadiumLighting: StadiumLightingPreset = StadiumLightingPreset.NIGHT,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(true) }
    val logs = remember { mutableStateListOf<TelemetryLog>() }
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss.SS", Locale.US) }
    var packetSeq by remember { mutableStateOf(1024) }

    fun addLog(tag: String, msg: String, tagColor: Color = Color(0xFF00FF66), msgColor: Color = Color(0xFFB0FFC8)) {
        val entry = TelemetryLog(
            timestamp = timeFormat.format(Date()),
            tag = tag,
            message = msg,
            tagColor = tagColor,
            msgColor = msgColor
        )
        logs.add(entry)
        if (logs.size > 28) {
            logs.removeAt(0)
        }
    }

    // Dynamic environment lighting telemetry log
    LaunchedEffect(stadiumLighting) {
        addLog(
            "ENV_LIGHT",
            "ATMOSPHERE=${stadiumLighting.name} // ${stadiumLighting.ambientDescription}",
            when (stadiumLighting) {
                StadiumLightingPreset.DAY -> Color(0xFF00E5FF)
                StadiumLightingPreset.DUSK -> Color(0xFFFF9900)
                StadiumLightingPreset.NIGHT -> Color(0xFF00FF66)
            }
        )
    }

    // Initial system boot logs
    LaunchedEffect(Unit) {
        addLog("SYS_INIT", "BADSHAH_DAEMON v2.6.4 STARTED // PORT 8080", Color(0xFF00E5FF))
        addLog("RADAR", "DOPPLER PITCH SENSOR ATTACHED (240 FPS)", Color(0xFF00FF66))
        addLog("AUDIO_SYNC", "EVENT BUS BOUND: BGM=OK SFX=OK DUCK=AUTO", Color(0xFFFFB800))
    }

    // Real-time telemetry streaming while ball is bowled
    LaunchedEffect(isBallInAir, currentDelivery) {
        if (isBallInAir) {
            packetSeq += Random.nextInt(3, 11)
            addLog(
                "PKT_RX",
                "SEQ#$packetSeq DELIV=${currentDelivery.name} SPEED=${currentDelivery.speedKph}km/h",
                Color(0xFF00E5FF),
                Color(0xFFE0F7FA)
            )
        }
    }

    // Progress updates as ball travels down the pitch
    LaunchedEffect(ballProgress) {
        if (isBallInAir) {
            val distM = ((1f - ballProgress) * 20.12f).coerceAtLeast(0f)
            when {
                ballProgress in 0.28f..0.34f -> {
                    packetSeq++
                    addLog(
                        "TRAJECTORY",
                        "Z_DIST: ${"%.1f".format(distM)}m // SWING_DRIFT: ${if (swingDrift > 0) "+" else ""}${"%.2f".format(swingDrift * 10)}°",
                        Color(0xFF00FF66)
                    )
                }
                ballProgress in 0.62f..0.68f -> {
                    packetSeq++
                    addLog(
                        "PITCH_BOUNCE",
                        "TURF_CONTACT: COMPRESSION=8.4kN // DEVIATION: ${(swingDrift * 4).toInt()}mm",
                        Color(0xFFFFB800),
                        Color(0xFFFFF9C4)
                    )
                }
                ballProgress in 0.82f..0.89f -> {
                    packetSeq++
                    addLog(
                        "SWEET_SPOT",
                        ">> HIT WINDOW OPEN: [82%..89%] DISCHARGE NOW! <<",
                        Color(0xFFFF334B),
                        Color(0xFFFFD54F)
                    )
                }
            }
        }
    }

    // Log shot event when ball concludes
    LaunchedEffect(lastShotResult) {
        if (lastShotResult != null && !isBallInAir) {
            when {
                lastShotResult.isSix -> {
                    addLog(
                        "PKT_TX",
                        "EVENT=SIX_OVERFLOW // DIST=${lastShotDistance}m // APOGEE=36.4m",
                        Color(0xFFFFB800),
                        Color(0xFFFFD700)
                    )
                    addLog(
                        "CORE_BOOST",
                        "ASTHETIC_BADSHAH_MAXIMUM >> AUDIO DUCKING TRIGGERED",
                        Color(0xFFFF334B),
                        Color(0xFFFFE082)
                    )
                }
                lastShotResult == ShotResult.FOUR -> {
                    addLog(
                        "BOUNDARY",
                        "CRACKING_FOUR // EXIT_VEL: 132km/h // CROWD_CHEER: ACTIVE",
                        Color(0xFF00E5FF),
                        Color(0xFF80DEEA)
                    )
                }
                lastShotResult == ShotResult.BOWLED -> {
                    addLog(
                        "CRIT_FAIL",
                        "STUMP_CIRCUIT_BROKEN // WICKET_COLLAPSE_DETECTED",
                        Color(0xFFFF334B),
                        Color(0xFFFFCDD2)
                    )
                }
                else -> {
                    addLog(
                        "LOG_STAT",
                        "SHOT_RESULT: ${lastShotResult.name} // SYSTEM IDLE",
                        Color(0xFF81C784),
                        Color(0xFFC8E6C9)
                    )
                }
            }
        }
    }

    // Background keep-alive heartbeat if idle
    LaunchedEffect(isBallInAir) {
        if (!isBallInAir) {
            while (true) {
                delay(4000)
                if (!isBallInAir) {
                    val pings = listOf(
                        "PACKET_STREAM: IDLE // FPS: 60.0 // LATENCY: 1.8ms",
                        "RADAR_BEAM: SCANNING PITCH AXIS // NOISE: -48dB",
                        "MASALA_CORE: READY // HEAP_ALLOC: 4.2MB"
                    )
                    addLog("SYS_DAEMON", pings[Random.nextInt(pings.size)], Color(0xFF00FF66).copy(alpha = 0.7f), Color(0xFF80E27E))
                }
            }
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    // Blinking live indicator
    val infiniteTransition = rememberInfiniteTransition(label = "terminalBlink")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "liveDot"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth(0.92f)
            .border(
                1.2.dp,
                Color(0xFF00FF66).copy(alpha = if (isBallInAir) 0.85f else 0.45f),
                RoundedCornerShape(12.dp)
            )
            .testTag("terminal_overlay_panel"),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xDD040906),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Pulsing green live dot
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(
                                (if (isBallInAir) Color(0xFFFFB800) else Color(0xFF00FF66)).copy(alpha = dotAlpha),
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Terminal Logs",
                        tint = Color(0xFF00FF66),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBallInAir) "TELEMETRY // LIVE PKT STREAM" else "TELEMETRY // SYSTEM_LOGS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isBallInAir) Color(0xFFFFB800) else Color(0xFF00FF66),
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color(0xFF00FF66).copy(alpha = 0.5f),
                                blurRadius = 6f
                            )
                        )
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isBallInAir) "${(ballProgress * 100).toInt()}%" else "STANDBY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.CloseFullscreen else Icons.Default.OpenInFull,
                            contentDescription = if (isExpanded) "Minimize" else "Expand",
                            tint = Color(0xFF00FF66),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 60.dp, max = 92.dp)
                        .padding(top = 4.dp)
                        .background(Color(0x88020503), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    // Scanline background decoration
                    Canvas(modifier = Modifier.matchParentSize()) {
                        for (y in 0 until size.height.toInt() step 5) {
                            drawLine(
                                color = Color(0x0F00FF66),
                                start = Offset(0f, y.toFloat()),
                                end = Offset(size.width, y.toFloat()),
                                strokeWidth = 1f
                            )
                        }
                    }

                    LazyColumn(
                        state = listState,
                        modifier = Modifier.matchParentSize()
                    ) {
                        items(logs, key = { it.id }) { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 1.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "[${log.tag}]",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = log.tagColor,
                                    modifier = Modifier.width(82.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = log.message,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = log.msgColor,
                                    lineHeight = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
