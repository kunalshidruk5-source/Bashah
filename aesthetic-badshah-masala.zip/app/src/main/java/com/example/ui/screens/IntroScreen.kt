package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val FULL_INTRO_TEXT = """
HI

WELCOME TO ASTHETIC BADSHAH CHAI GARAM MASALA GAME

BY VED KHOPDE

CREATED BY KUNAL SHIDRUK

AND CO POWERED BY

RAJ PAWAR
SHRAVAN SHELAR
MEET NAKHWA
VEDANT DHAMAL
TUSHAR
YASH
OM JAGTAP
PUNEETA
AND OTHERS

THANKS FOR PLAYING ASTHETIC BADSHAH MASALA
""".trimIndent()

@Composable
fun IntroScreen(
    onIntroFinished: () -> Unit,
    playIntroAudio: (() -> Unit) -> Unit,
    stopIntroAudio: () -> Unit
) {
    var displayedCharsCount by remember { mutableIntStateOf(0) }
    var isTypingComplete by remember { mutableStateOf(false) }

    // Start intro audio on launch
    LaunchedEffect(Unit) {
        playIntroAudio {
            isTypingComplete = true
        }

        // Total duration ~24s synchronized with audio
        val totalChars = FULL_INTRO_TEXT.length
        val charDelayMs = (24000L / totalChars).coerceIn(40L, 75L)

        for (i in 1..totalChars) {
            displayedCharsCount = i
            // Keystroke sound or small micro pause on newlines
            if (FULL_INTRO_TEXT[i - 1] == '\n') {
                delay(charDelayMs * 2)
            } else {
                delay(charDelayMs)
            }
        }
        isTypingComplete = true
        delay(1800)
        onIntroFinished()
    }

    DisposableEffect(Unit) {
        onDispose {
            stopIntroAudio()
        }
    }

    // Blinking cursor animation
    val infiniteTransition = rememberInfiniteTransition(label = "cursor")
    val cursorAlpha by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )

    // Glitch / Scanline effect offset
    val scanlineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline"
    )

    val displayedText = FULL_INTRO_TEXT.take(displayedCharsCount)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030507))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                // Tapping anywhere can speed up or skip to main menu
                onIntroFinished()
            }
    ) {
        // Subtle matrix/hacker rain background effect
        MatrixDigitalRain()

        // Scanline overlay canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 6f
            for (y in 0 until size.height.toInt() step step.toInt()) {
                drawLine(
                    color = Color(0x0A00FF66),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 1.2f
                )
            }
            // Moving scan beam
            val beamY = (scanlineY % size.height)
            drawLine(
                color = Color(0x1F00FF88),
                start = Offset(0f, beamY),
                end = Offset(size.width, beamY),
                strokeWidth = 3f
            )
        }

        // Top system header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Hacker Terminal",
                    tint = Color(0xFF00FF66),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SYS::TERMINAL // BADSHAH_V2.6",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00FF66).copy(alpha = 0.8f)
                )
            }

            // Skip button
            Button(
                onClick = onIntroFinished,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00FF66).copy(alpha = 0.15f),
                    contentColor = Color(0xFF00FF66)
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .border(1.dp, Color(0xFF00FF66).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .testTag("skip_intro_button")
            ) {
                Text(
                    text = "SKIP >>",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Terminal Content
        val scrollState = rememberScrollState()
        LaunchedEffect(displayedCharsCount) {
            scrollState.scrollTo(scrollState.maxValue)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 80.dp, bottom = 90.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            // Header prompt line
            Text(
                text = "> INITIALIZING ASTHETIC ENGINE...",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color(0xFF00CC55).copy(alpha = 0.7f)
            )
            Text(
                text = "> AUDIO CHANNEL SYNC: ONLINE",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color(0xFF00CC55).copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Main hacker green typed text
            Text(
                text = displayedText,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 26.sp,
                    color = Color(0xFF00FF66),
                    shadow = Shadow(
                        color = Color(0xFF00FF66).copy(alpha = 0.7f),
                        blurRadius = 14f
                    )
                )
            )

            // Blinking terminal cursor
            Text(
                text = "█",
                fontFamily = FontFamily.Monospace,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00FF66).copy(alpha = cursorAlpha),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Bottom continue trigger if typing complete
        if (isTypingComplete) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 28.dp)
            ) {
                Button(
                    onClick = onIntroFinished,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00FF66),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(52.dp)
                        .testTag("continue_to_menu_button")
                ) {
                    Text(
                        text = "ENTER GAME // PRESS TO START",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Enter",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MatrixDigitalRain() {
    val random = remember { Random(42) }
    val glyphs = remember {
        List(24) {
            MatrixStream(
                x = it * 0.042f + 0.02f,
                speed = random.nextFloat() * 0.003f + 0.002f,
                chars = (0..12).map { (random.nextInt(33, 126)).toChar().toString() }
            )
        }
    }

    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(50)
            tick++
        }
    }

    Canvas(modifier = Modifier.fillMaxSize().alpha(0.12f)) {
        val w = size.width
        val h = size.height

        glyphs.forEachIndexed { i, stream ->
            val yPos = ((tick * stream.speed * h + i * 40f) % (h + 200f)) - 100f
            stream.chars.forEachIndexed { charIdx, ch ->
                val charY = yPos + charIdx * 18f
                if (charY in 0f..h) {
                    val alpha = if (charIdx == stream.chars.size - 1) 0.9f else 0.4f
                    // Draw digital green drops
                    drawCircle(
                        color = Color(0xFF00FF66).copy(alpha = alpha),
                        radius = 1.5f,
                        center = Offset(stream.x * w, charY)
                    )
                }
            }
        }
    }
}

private data class MatrixStream(
    val x: Float,
    val speed: Float,
    val chars: List<String>
)
