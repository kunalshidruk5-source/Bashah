package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.audio.AudioController
import com.example.model.AppScreen
import com.example.model.CurrentMatch
import com.example.model.DeliveryLength
import com.example.model.Particle
import com.example.model.PlayerStats
import com.example.model.ShotResult
import com.example.model.ShotType
import com.example.model.StadiumLightingPreset
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class CricketGameViewModel(application: Application) : AndroidViewModel(application) {
    val audioController = AudioController(application)

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val statsPrefs = application.getSharedPreferences("badshah_cricket_stats", Context.MODE_PRIVATE)

    private val _currentScreen = MutableStateFlow(AppScreen.INTRO)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _stats = MutableStateFlow(
        PlayerStats(
            totalRuns = statsPrefs.getInt("total_runs", 0),
            totalBalls = statsPrefs.getInt("total_balls", 0),
            totalSixes = statsPrefs.getInt("total_sixes", 0),
            totalFours = statsPrefs.getInt("total_fours", 0),
            wicketsLost = statsPrefs.getInt("wickets_lost", 0),
            highestScore = statsPrefs.getInt("highest_score", 0),
            longestSixMeters = statsPrefs.getInt("longest_six", 0),
            matchesPlayed = statsPrefs.getInt("matches_played", 0)
        )
    )
    val stats: StateFlow<PlayerStats> = _stats.asStateFlow()

    private val _match = MutableStateFlow(CurrentMatch())
    val match: StateFlow<CurrentMatch> = _match.asStateFlow()

    // Bowling & Ball Physics Animation State
    private val _ballProgress = MutableStateFlow(0f) // 0.0 (bowler hand) -> 1.0 (past batsman)
    val ballProgress: StateFlow<Float> = _ballProgress.asStateFlow()

    private val _isBallInAir = MutableStateFlow(false)
    val isBallInAir: StateFlow<Boolean> = _isBallInAir.asStateFlow()

    private val _currentDelivery = MutableStateFlow(DeliveryLength.GOOD_LENGTH)
    val currentDelivery: StateFlow<DeliveryLength> = _currentDelivery.asStateFlow()

    private val _swingDrift = MutableStateFlow(0f)
    val swingDrift: StateFlow<Float> = _swingDrift.asStateFlow()

    // Batting swing state
    private val _batSwingAngle = MutableStateFlow(0f) // 0f normal, -60f backlift, 60f follow-through
    val batSwingAngle: StateFlow<Float> = _batSwingAngle.asStateFlow()

    private val _selectedShot = MutableStateFlow(ShotType.STRAIGHT_LOFT)
    val selectedShot: StateFlow<ShotType> = _selectedShot.asStateFlow()

    // Six celebration state
    private val _isSixCelebration = MutableStateFlow(false)
    val isSixCelebration: StateFlow<Boolean> = _isSixCelebration.asStateFlow()

    private val _sixBallFlightProgress = MutableStateFlow(0f) // 0 to 1 during six arc
    val sixBallFlightProgress: StateFlow<Float> = _sixBallFlightProgress.asStateFlow()

    private val _isWicketDown = MutableStateFlow(false)
    val isWicketDown: StateFlow<Boolean> = _isWicketDown.asStateFlow()

    // Celebration fireworks/particles
    private val _particles = MutableStateFlow<List<Particle>>(emptyList())
    val particles: StateFlow<List<Particle>> = _particles.asStateFlow()

    // 3D Stadium Lighting Preset: Day, Dusk, Night
    private val _stadiumLighting = MutableStateFlow(StadiumLightingPreset.NIGHT)
    val stadiumLighting: StateFlow<StadiumLightingPreset> = _stadiumLighting.asStateFlow()

    fun toggleRandomLighting() {
        val presets = StadiumLightingPreset.values()
        val nextOptions = presets.filter { it != _stadiumLighting.value }
        _stadiumLighting.value = nextOptions[Random.nextInt(nextOptions.size)]
        audioController.playSfx(R.raw.sfx_click)
    }

    fun setLightingPreset(preset: StadiumLightingPreset) {
        _stadiumLighting.value = preset
        audioController.playSfx(R.raw.sfx_click)
    }

    private var deliveryJob: Job? = null
    private var swingJob: Job? = null
    private var particleJob: Job? = null
    private var hasHitBallInCurrentDelivery = false

    fun navigateTo(screen: AppScreen) {
        audioController.playSfx(R.raw.sfx_click)
        if (_currentScreen.value == AppScreen.INTRO && screen != AppScreen.INTRO) {
            audioController.stopIntroAudio()
        }
        if (screen == AppScreen.GAMEPLAY) {
            audioController.startBgm()
            startNewMatch()
        } else if (_currentScreen.value == AppScreen.GAMEPLAY && screen != AppScreen.GAMEPLAY) {
            audioController.stopBgm()
        }
        _currentScreen.value = screen
    }

    fun startIntroAudio(onFinished: () -> Unit) {
        audioController.playIntroAudio {
            onFinished()
        }
    }

    fun selectShot(shot: ShotType) {
        audioController.playSfx(R.raw.sfx_click)
        _selectedShot.value = shot
    }

    fun startNewMatch() {
        deliveryJob?.cancel()
        _match.value = CurrentMatch()
        _isSixCelebration.value = false
        _isWicketDown.value = false
        _ballProgress.value = 0f
        _isBallInAir.value = false
        hasHitBallInCurrentDelivery = false

        // Randomly select stadium atmosphere preset (Day, Dusk, Night)
        val presets = StadiumLightingPreset.values()
        _stadiumLighting.value = presets[Random.nextInt(presets.size)]

        // Start first ball after 1.5 seconds
        viewModelScope.launch {
            delay(1200)
            bowlNextBall()
        }
    }

    fun bowlNextBall() {
        if (_match.value.isGameOver) return
        if (_isBallInAir.value) return

        deliveryJob?.cancel()
        _isSixCelebration.value = false
        _isWicketDown.value = false
        hasHitBallInCurrentDelivery = false
        _batSwingAngle.value = 0f

        // Randomize delivery length and swing
        val deliveries = DeliveryLength.values()
        val randomDelivery = deliveries[Random.nextInt(deliveries.size)]
        _currentDelivery.value = randomDelivery
        _swingDrift.value = (Random.nextFloat() - 0.5f) * 0.4f // -0.2 to +0.2

        audioController.playSfx(R.raw.sfx_bowl)
        _isBallInAir.value = true

        deliveryJob = viewModelScope.launch {
            val totalDurationMs = when (randomDelivery) {
                DeliveryLength.YORKER -> 1300L
                DeliveryLength.GOOD_LENGTH -> 1450L
                DeliveryLength.FULL_LENGTH -> 1500L
                DeliveryLength.SHORT_BOUNCER -> 1350L
                DeliveryLength.SLOWER_BALL -> 1900L
            }

            val startTime = System.currentTimeMillis()
            while (isActive) {
                val elapsed = System.currentTimeMillis() - startTime
                val progress = (elapsed.toFloat() / totalDurationMs).coerceIn(0f, 1f)
                _ballProgress.value = progress

                if (progress >= 1f) {
                    break
                }
                delay(16) // ~60fps
            }

            // If player didn't hit the ball:
            if (!hasHitBallInCurrentDelivery) {
                onBallMissed(randomDelivery)
            }
        }
    }

    private fun onBallMissed(delivery: DeliveryLength) {
        _isBallInAir.value = false
        // Yorker or good length hitting stumps if line is straight
        val isBowled = (delivery == DeliveryLength.YORKER || delivery == DeliveryLength.GOOD_LENGTH) &&
                kotlin.math.abs(_swingDrift.value) < 0.12f

        if (isBowled) {
            _isWicketDown.value = true
            audioController.playSfx(R.raw.sfx_wicket)
            vibrate(300L)
            recordBallResult(ShotResult.BOWLED, 0)
        } else {
            audioController.playSfx(R.raw.sfx_bat_hit)
            recordBallResult(ShotResult.DOT, 0)
        }

        scheduleNextBallAfterResult()
    }

    /**
     * Called when the player taps the BAT / SWING button.
     */
    fun onBatSwing() {
        if (!_isBallInAir.value || hasHitBallInCurrentDelivery) return

        hasHitBallInCurrentDelivery = true
        deliveryJob?.cancel()

        // Trigger bat animation
        animateBatSwing()

        val progress = _ballProgress.value
        // Sweet spot is between 0.78 and 0.92
        // Perfect Six is between 0.82 and 0.89!
        val result: ShotResult
        val distance: Int

        when {
            // Sweet spot: PERFECT TIMING -> SIX!
            progress in 0.82f..0.89f -> {
                result = ShotResult.SIX
                distance = Random.nextInt(98, 126)
                triggerSixHit(distance)
            }
            // Slightly early or late: FOUR!
            progress in 0.76f..0.94f -> {
                result = ShotResult.FOUR
                distance = Random.nextInt(68, 88)
                triggerRegularHit(result, distance)
            }
            // Fair timing: 2 runs or 1 run
            progress in 0.70f..0.98f -> {
                val isTwo = Random.nextBoolean()
                result = if (isTwo) ShotResult.TWO else ShotResult.ONE
                distance = Random.nextInt(30, 60)
                triggerRegularHit(result, distance)
            }
            // Very early or late: Missed or Bowled
            else -> {
                val isLate = progress > 0.98f
                if (isLate && (_currentDelivery.value == DeliveryLength.YORKER || _currentDelivery.value == DeliveryLength.GOOD_LENGTH)) {
                    result = ShotResult.BOWLED
                    distance = 0
                    _isWicketDown.value = true
                    audioController.playSfx(R.raw.sfx_wicket)
                    vibrate(350L)
                } else {
                    result = ShotResult.MISSED
                    distance = 0
                    audioController.playSfx(R.raw.sfx_bat_hit)
                }
            }
        }

        recordBallResult(result, distance)
        scheduleNextBallAfterResult()
    }

    private fun animateBatSwing() {
        swingJob?.cancel()
        swingJob = viewModelScope.launch {
            // Backlift to forward lofted stroke
            _batSwingAngle.value = -45f
            delay(40)
            _batSwingAngle.value = 35f
            delay(50)
            _batSwingAngle.value = 75f
            delay(120)
            _batSwingAngle.value = 40f
            delay(150)
            _batSwingAngle.value = 0f
        }
    }

    private fun triggerSixHit(distanceMeters: Int) {
        vibrate(500L)
        audioController.playSixCelebration()
        _isSixCelebration.value = true

        // Launch celebratory fireworks & particles
        spawnCelebrationParticles()

        // Animate six ball flight arc into the stadium stands
        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val duration = 2400L
            while (isActive) {
                val elapsed = System.currentTimeMillis() - startTime
                val p = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
                _sixBallFlightProgress.value = p
                if (p >= 1f) break
                delay(16)
            }
        }
    }

    private fun triggerRegularHit(result: ShotResult, distanceMeters: Int) {
        audioController.playSfx(R.raw.sfx_bat_hit)
        vibrate(100L)
        if (result == ShotResult.FOUR) {
            audioController.playSfx(R.raw.sfx_cheer)
        }
    }

    private fun recordBallResult(result: ShotResult, distanceMeters: Int) {
        val current = _match.value
        val newRuns = current.runs + result.runs
        val newWickets = if (result == ShotResult.BOWLED) current.wickets + 1 else current.wickets
        val newBalls = current.ballsBowled + 1
        val newSixes = if (result.isSix) current.sixesInMatch + 1 else current.sixesInMatch
        val maxBalls = current.maxOvers * 6
        val isOver = newBalls >= maxBalls || newWickets >= 3

        val updatedRecent = (listOf(
            when {
                result.isSix -> "6"
                result == ShotResult.FOUR -> "4"
                result == ShotResult.BOWLED -> "W"
                result.runs > 0 -> "${result.runs}"
                else -> "•"
            }
        ) + current.recentBalls).take(6)

        _match.value = current.copy(
            runs = newRuns,
            wickets = newWickets,
            ballsBowled = newBalls,
            sixesInMatch = newSixes,
            lastShotResult = result,
            lastShotDistance = distanceMeters,
            isGameOver = isOver,
            recentBalls = updatedRecent
        )

        // Update overall stats
        updateLifetimeStats(result, distanceMeters, isOver)
    }

    private fun updateLifetimeStats(result: ShotResult, distanceMeters: Int, matchEnded: Boolean) {
        val s = _stats.value
        val newRuns = s.totalRuns + result.runs
        val newBalls = s.totalBalls + 1
        val newSixes = s.totalSixes + (if (result.isSix) 1 else 0)
        val newFours = s.totalFours + (if (result == ShotResult.FOUR) 1 else 0)
        val newWickets = s.wicketsLost + (if (result == ShotResult.BOWLED) 1 else 0)
        val newHighest = kotlin.math.max(s.highestScore, _match.value.runs)
        val newLongestSix = kotlin.math.max(s.longestSixMeters, distanceMeters)
        val newMatches = s.matchesPlayed + (if (matchEnded) 1 else 0)

        val updatedStats = s.copy(
            totalRuns = newRuns,
            totalBalls = newBalls,
            totalSixes = newSixes,
            totalFours = newFours,
            wicketsLost = newWickets,
            highestScore = newHighest,
            longestSixMeters = newLongestSix,
            matchesPlayed = newMatches
        )
        _stats.value = updatedStats

        statsPrefs.edit()
            .putInt("total_runs", newRuns)
            .putInt("total_balls", newBalls)
            .putInt("total_sixes", newSixes)
            .putInt("total_fours", newFours)
            .putInt("wickets_lost", newWickets)
            .putInt("highest_score", newHighest)
            .putInt("longest_six", newLongestSix)
            .putInt("matches_played", newMatches)
            .apply()
    }

    private fun scheduleNextBallAfterResult() {
        viewModelScope.launch {
            val waitTime = if (_isSixCelebration.value) 4200L else 2200L
            delay(waitTime)
            _isSixCelebration.value = false
            _isBallInAir.value = false
            _particles.value = emptyList()

            if (!_match.value.isGameOver) {
                bowlNextBall()
            }
        }
    }

    private fun spawnCelebrationParticles() {
        particleJob?.cancel()
        particleJob = viewModelScope.launch {
            val colors = listOf(
                0xFFFFB800, // Gold
                0xFFFF334B, // Badshah red
                0xFF00FF66, // Green
                0xFF00E5FF, // Cyan
                0xFFFF6B00  // Orange
            )
            val newParticles = (0..60).map {
                val angle = Random.nextFloat() * 2 * Math.PI.toFloat()
                val speed = Random.nextFloat() * 14f + 6f
                Particle(
                    x = 0.5f,
                    y = 0.45f,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed - 4f,
                    color = colors[Random.nextInt(colors.size)],
                    radius = Random.nextFloat() * 7f + 3f,
                    alpha = 1f
                )
            }
            _particles.value = newParticles

            var current = newParticles
            while (isActive && current.isNotEmpty()) {
                delay(20)
                current = current.mapNotNull { p ->
                    if (p.alpha <= 0.05f) null
                    else p.copy(
                        x = p.x + p.vx * 0.001f,
                        y = p.y + p.vy * 0.001f,
                        vy = p.vy + 0.35f, // Gravity
                        alpha = p.alpha - 0.02f
                    )
                }
                _particles.value = current
            }
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (e: Exception) {
            // Ignore if vibration not permitted
        }
    }

    override fun onCleared() {
        super.onCleared()
        deliveryJob?.cancel()
        swingJob?.cancel()
        particleJob?.cancel()
        audioController.release()
    }
}
