package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.model.AppScreen
import com.example.ui.screens.CreditsScreen
import com.example.ui.screens.CricketStadiumScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.IntroScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.CricketGameViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: CricketGameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        when (event) {
                            Lifecycle.Event.ON_PAUSE -> {
                                viewModel.audioController.pauseBgm()
                                viewModel.audioController.stopIntroAudio()
                            }
                            Lifecycle.Event.ON_RESUME -> {
                                if (viewModel.currentScreen.value == AppScreen.GAMEPLAY) {
                                    viewModel.audioController.resumeBgm()
                                }
                            }
                            Lifecycle.Event.ON_DESTROY -> {
                                viewModel.audioController.release()
                            }
                            else -> {}
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                val currentScreen by viewModel.currentScreen.collectAsState()
                val stats by viewModel.stats.collectAsState()

                // Back navigation handling
                BackHandler(enabled = currentScreen != AppScreen.MAIN_MENU && currentScreen != AppScreen.INTRO) {
                    when (currentScreen) {
                        AppScreen.GAMEPLAY, AppScreen.HOW_TO_PLAY, AppScreen.CREDITS -> {
                            viewModel.navigateTo(AppScreen.MAIN_MENU)
                        }
                        else -> {}
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = DarkBackground
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "ScreenTransition"
                    ) { screen ->
                        when (screen) {
                            AppScreen.INTRO -> {
                                IntroScreen(
                                    onIntroFinished = {
                                        viewModel.navigateTo(AppScreen.MAIN_MENU)
                                    },
                                    playIntroAudio = { onFinish ->
                                        viewModel.startIntroAudio(onFinish)
                                    },
                                    stopIntroAudio = {
                                        viewModel.audioController.stopIntroAudio()
                                    }
                                )
                            }
                            AppScreen.MAIN_MENU -> {
                                MainMenuScreen(
                                    stats = stats,
                                    audioController = viewModel.audioController,
                                    onStartGame = {
                                        viewModel.navigateTo(AppScreen.GAMEPLAY)
                                    },
                                    onShowHowToPlay = {
                                        viewModel.navigateTo(AppScreen.HOW_TO_PLAY)
                                    },
                                    onShowCredits = {
                                        viewModel.navigateTo(AppScreen.CREDITS)
                                    }
                                )
                            }
                            AppScreen.GAMEPLAY -> {
                                CricketStadiumScreen(
                                    viewModel = viewModel,
                                    onBackToMenu = {
                                        viewModel.navigateTo(AppScreen.MAIN_MENU)
                                    }
                                )
                            }
                            AppScreen.HOW_TO_PLAY -> {
                                HowToPlayScreen(
                                    onBack = {
                                        viewModel.navigateTo(AppScreen.MAIN_MENU)
                                    }
                                )
                            }
                            AppScreen.CREDITS -> {
                                CreditsScreen(
                                    onBack = {
                                        viewModel.navigateTo(AppScreen.MAIN_MENU)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
