package com.example.model

enum class AppScreen {
    INTRO,
    MAIN_MENU,
    GAMEPLAY,
    HOW_TO_PLAY,
    CREDITS
}

enum class DeliveryLength(val label: String, val speedKph: Int) {
    FULL_LENGTH("Full Length", 138),
    GOOD_LENGTH("Good Length", 142),
    YORKER("Laser Yorker", 148),
    SHORT_BOUNCER("Fast Bouncer", 145),
    SLOWER_BALL("Masala Slower Ball", 112)
}

enum class StadiumLightingPreset(
    val label: String,
    val iconEmoji: String,
    val ambientDescription: String
) {
    DAY("Day", "☀️", "Sunny Afternoon • Clear Sky"),
    DUSK("Dusk", "🌇", "Twilight Golden Hour • Amber Glow"),
    NIGHT("Night", "🌙", "Midnight Stadium • Electric Floodlights")
}

enum class ShotType(val label: String, val angleDeg: Float) {
    STRAIGHT_LOFT("Straight Loft", 0f),
    PULL_SHOT("Deep Mid-Wicket Pull", -55f),
    COVER_DRIVE("Inside-Out Cover Drive", 50f),
    HELICOPTER_SHOT("Badshah Special Helicopter", -15f)
}

enum class ShotResult(val runs: Int, val isSix: Boolean, val message: String, val badgeColor: Long) {
    SIX(6, true, "MASSIVE SIX! OUT OF THE STADIUM!", 0xFFFFB800),
    FOUR(4, false, "CRACKING FOUR! TO THE FENCE!", 0xFF00E5FF),
    TWO(2, false, "DOUBLE! QUICK RUNNING!", 0xFF4CAF50),
    ONE(1, false, "SINGLE TAKEN", 0xFF81C784),
    DOT(0, false, "DOT BALL • DEFENDED", 0xFF9E9E9E),
    BOWLED(0, false, "CLEAN BOWLED! STUMPS SHATTERED!", 0xFFFF334B),
    MISSED(0, false, "BEATEN OUTSIDE OFF!", 0xFFFF9800)
}

data class BowledBall(
    val length: DeliveryLength,
    val swingOffset: Float, // horizontal drift -1.0 to 1.0
    val releaseTime: Long
)

data class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Long,
    val radius: Float,
    val alpha: Float,
    val life: Float = 1f
)

data class PlayerStats(
    val totalRuns: Int = 0,
    val totalBalls: Int = 0,
    val totalSixes: Int = 0,
    val totalFours: Int = 0,
    val wicketsLost: Int = 0,
    val highestScore: Int = 0,
    val longestSixMeters: Int = 0,
    val matchesPlayed: Int = 0
)

data class CurrentMatch(
    val runs: Int = 0,
    val wickets: Int = 0,
    val ballsBowled: Int = 0,
    val maxOvers: Int = 2, // 12 balls per quick match
    val sixesInMatch: Int = 0,
    val lastShotResult: ShotResult? = null,
    val lastShotDistance: Int = 0,
    val isGameOver: Boolean = false,
    val recentBalls: List<String> = emptyList()
)
