package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.annotation.RawRes
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AudioSettings(
    val bgmVolume: Float = 0.8f,
    val sfxVolume: Float = 1.0f,
    val introVolume: Float = 1.0f,
    val sixVolume: Float = 1.0f,
    val isMuted: Boolean = false
)

class AudioController(private val context: Context) {
    private val prefs = context.getSharedPreferences("badshah_audio_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        AudioSettings(
            bgmVolume = prefs.getFloat("bgm_vol", 0.8f),
            sfxVolume = prefs.getFloat("sfx_vol", 1.0f),
            introVolume = prefs.getFloat("intro_vol", 1.0f),
            sixVolume = prefs.getFloat("six_vol", 1.0f),
            isMuted = prefs.getBoolean("is_muted", false)
        )
    )
    val settings: StateFlow<AudioSettings> = _settings.asStateFlow()

    private var introPlayer: MediaPlayer? = null
    private var bgmPlayer: MediaPlayer? = null
    private var isBgmDucked = false
    private var duckJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<Int, Int>()

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(audioAttributes)
            .build()

        // Preload sound effects
        loadSound(R.raw.sfx_six)
        loadSound(R.raw.sfx_bat_hit)
        loadSound(R.raw.sfx_wicket)
        loadSound(R.raw.sfx_bowl)
        loadSound(R.raw.sfx_cheer)
        loadSound(R.raw.sfx_click)
    }

    private fun loadSound(@RawRes resId: Int) {
        val soundId = soundPool.load(context, resId, 1)
        soundMap[resId] = soundId
    }

    fun playIntroAudio(onCompletion: (() -> Unit)? = null) {
        stopIntroAudio()
        if (_settings.value.isMuted) return

        try {
            introPlayer = MediaPlayer.create(context, R.raw.intro_audio)?.apply {
                val vol = _settings.value.introVolume
                setVolume(vol, vol)
                setOnCompletionListener {
                    onCompletion?.invoke()
                }
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopIntroAudio() {
        introPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        introPlayer = null
    }

    fun startBgm() {
        if (bgmPlayer != null && bgmPlayer?.isPlaying == true) return
        stopBgm()
        if (_settings.value.isMuted) return

        try {
            bgmPlayer = MediaPlayer.create(context, R.raw.bgm_gameplay)?.apply {
                isLooping = true
                val vol = if (isBgmDucked) _settings.value.bgmVolume * 0.25f else _settings.value.bgmVolume
                setVolume(vol, vol)
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopBgm() {
        bgmPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        bgmPlayer = null
    }

    fun pauseBgm() {
        bgmPlayer?.let {
            if (it.isPlaying) {
                it.pause()
            }
        }
    }

    fun resumeBgm() {
        if (_settings.value.isMuted) return
        bgmPlayer?.start()
    }

    /**
     * Ducks the background music volume while important event audio (e.g. Six audio) plays,
     * and automatically restores the BGM volume afterward.
     */
    fun duckBgmForDuration(durationMs: Long = 4000L) {
        if (bgmPlayer == null || _settings.value.isMuted) return
        duckJob?.cancel()
        isBgmDucked = true
        val targetDuckedVol = _settings.value.bgmVolume * 0.25f
        bgmPlayer?.setVolume(targetDuckedVol, targetDuckedVol)

        duckJob = scope.launch {
            delay(durationMs)
            isBgmDucked = false
            val normalVol = _settings.value.bgmVolume
            bgmPlayer?.setVolume(normalVol, normalVol)
        }
    }

    fun playSfx(@RawRes resId: Int) {
        if (_settings.value.isMuted) return
        val soundId = soundMap[resId] ?: return
        val vol = if (resId == R.raw.sfx_six) {
            _settings.value.sixVolume
        } else {
            _settings.value.sfxVolume
        }
        soundPool.play(soundId, vol, vol, 1, 0, 1.0f)
    }

    fun playSixCelebration() {
        // Play six hit sound effect + announcement
        playSfx(R.raw.sfx_six)
        // Duck the background music while the six announcement and cheer play
        duckBgmForDuration(4500L)
    }

    fun updateBgmVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _settings.value = _settings.value.copy(bgmVolume = clamped)
        prefs.edit().putFloat("bgm_vol", clamped).apply()
        val currentVol = if (isBgmDucked) clamped * 0.25f else clamped
        bgmPlayer?.setVolume(currentVol, currentVol)
    }

    fun updateSfxVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _settings.value = _settings.value.copy(sfxVolume = clamped)
        prefs.edit().putFloat("sfx_vol", clamped).apply()
    }

    fun updateIntroVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _settings.value = _settings.value.copy(introVolume = clamped)
        prefs.edit().putFloat("intro_vol", clamped).apply()
        introPlayer?.setVolume(clamped, clamped)
    }

    fun updateSixVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        _settings.value = _settings.value.copy(sixVolume = clamped)
        prefs.edit().putFloat("six_vol", clamped).apply()
    }

    fun toggleMute() {
        val newMuted = !_settings.value.isMuted
        _settings.value = _settings.value.copy(isMuted = newMuted)
        prefs.edit().putBoolean("is_muted", newMuted).apply()
        if (newMuted) {
            bgmPlayer?.setVolume(0f, 0f)
            introPlayer?.setVolume(0f, 0f)
        } else {
            val bgmVol = if (isBgmDucked) _settings.value.bgmVolume * 0.25f else _settings.value.bgmVolume
            bgmPlayer?.setVolume(bgmVol, bgmVol)
            introPlayer?.setVolume(_settings.value.introVolume, _settings.value.introVolume)
        }
    }

    fun release() {
        duckJob?.cancel()
        stopIntroAudio()
        stopBgm()
        soundPool.release()
    }
}
